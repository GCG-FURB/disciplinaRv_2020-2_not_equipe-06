using RootSystem = System;
using System.Linq;
using System.Collections.Generic;
namespace Windows.Kinect
{
    //
    // Windows.Kinect.Expression
    //
    public enum Expression : int
    {
        Neutral                                  =0,
        Happy                                    =1,
    }

}
